var p5Inst = new p5(null, 'sketch');

window.preload = function () {
  initMobileControls(p5Inst);

  p5Inst._predefinedSpriteAnimations = {};
  p5Inst._pauseSpriteAnimationsByDefault = false;
  var animationListJSON = {"orderedKeys":["5511b4c9-6cd0-4066-a958-33c71253c774","2b82666a-580b-4f33-98e0-70d2b7fddf36","115c3e69-7cb9-40a1-afc2-318897ce393c","4b6fe855-4039-4290-87b7-933b2770d1f0","ab817f24-757f-4add-9250-eb2e05ade376","2bf96340-0408-402e-add6-14acc0ca8ee3","ed696b9e-157f-46aa-bbc8-ec8c0bad2b2d","317c6514-299f-4c8d-a67f-f7723f1e7265"],"propsByKey":{"5511b4c9-6cd0-4066-a958-33c71253c774":{"name":"fox_1","sourceUrl":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png","frameSize":{"x":394,"y":260},"frameCount":1,"looping":true,"frameDelay":2,"version":"si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":394,"y":260},"rootRelativePath":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png"},"2b82666a-580b-4f33-98e0-70d2b7fddf36":{"name":"fox_2","sourceUrl":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png","frameSize":{"x":394,"y":260},"frameCount":1,"looping":true,"frameDelay":2,"version":"si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":394,"y":260},"rootRelativePath":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png"},"115c3e69-7cb9-40a1-afc2-318897ce393c":{"name":"fox_3","sourceUrl":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png","frameSize":{"x":394,"y":260},"frameCount":1,"looping":true,"frameDelay":2,"version":"si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":394,"y":260},"rootRelativePath":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png"},"4b6fe855-4039-4290-87b7-933b2770d1f0":{"name":"fox_4","sourceUrl":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png","frameSize":{"x":394,"y":260},"frameCount":1,"looping":true,"frameDelay":2,"version":"si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":394,"y":260},"rootRelativePath":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png"},"ab817f24-757f-4add-9250-eb2e05ade376":{"name":"fox_5","sourceUrl":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png","frameSize":{"x":394,"y":260},"frameCount":1,"looping":true,"frameDelay":2,"version":"si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x","categories":["animals"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":394,"y":260},"rootRelativePath":"assets/api/v1/animation-library/gamelab/si6fMWPKidsNx06Vyp43ncgB2o8Ygc.x/category_animals/fox.png"},"2bf96340-0408-402e-add6-14acc0ca8ee3":{"name":"pine_trees_1","sourceUrl":null,"frameSize":{"x":386,"y":267},"frameCount":1,"looping":true,"frameDelay":12,"version":"Y0EGZnv4NciHTb9SLfDnbSf9VK4555Ya","categories":["backgrounds"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":386,"y":267},"rootRelativePath":"assets/2bf96340-0408-402e-add6-14acc0ca8ee3.png"},"ed696b9e-157f-46aa-bbc8-ec8c0bad2b2d":{"name":"rpgcharacter_11_1","sourceUrl":"assets/api/v1/animation-library/gamelab/8AmDG487lonn5isbI5elQ3ee8xDHqDsZ/category_fantasy/rpgcharacter_11.png","frameSize":{"x":252,"y":332},"frameCount":1,"looping":true,"frameDelay":2,"version":"8AmDG487lonn5isbI5elQ3ee8xDHqDsZ","categories":["fantasy"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":252,"y":332},"rootRelativePath":"assets/api/v1/animation-library/gamelab/8AmDG487lonn5isbI5elQ3ee8xDHqDsZ/category_fantasy/rpgcharacter_11.png"},"317c6514-299f-4c8d-a67f-f7723f1e7265":{"name":"beachhouse_03_1","sourceUrl":"assets/api/v1/animation-library/gamelab/9gnAnMn.a_Dr0fbc82MaVi.LIRG.XF8B/category_buildings/beachhouse_03.png","frameSize":{"x":342,"y":333},"frameCount":1,"looping":true,"frameDelay":2,"version":"9gnAnMn.a_Dr0fbc82MaVi.LIRG.XF8B","categories":["buildings"],"loadedFromSource":true,"saved":true,"sourceSize":{"x":342,"y":333},"rootRelativePath":"assets/api/v1/animation-library/gamelab/9gnAnMn.a_Dr0fbc82MaVi.LIRG.XF8B/category_buildings/beachhouse_03.png"}}};
  var orderedKeys = animationListJSON.orderedKeys;
  var allAnimationsSingleFrame = false;
  orderedKeys.forEach(function (key) {
    var props = animationListJSON.propsByKey[key];
    var frameCount = allAnimationsSingleFrame ? 1 : props.frameCount;
    var image = loadImage(props.rootRelativePath, function () {
      var spriteSheet = loadSpriteSheet(
          image,
          props.frameSize.x,
          props.frameSize.y,
          frameCount
      );
      p5Inst._predefinedSpriteAnimations[props.name] = loadAnimation(spriteSheet);
      p5Inst._predefinedSpriteAnimations[props.name].looping = props.looping;
      p5Inst._predefinedSpriteAnimations[props.name].frameDelay = props.frameDelay;
    });
  });

  function wrappedExportedCode(stage) {
    if (stage === 'preload') {
      if (setup !== window.setup) {
        window.setup = setup;
      } else {
        return;
      }
    }
// -----

var life = 0;
var fox1, fox2, fox3,fox4,fox5;
var scenery;
var house;
var grandmaa;
var gameState="serve";
var boundry1,boundary2;
  var scenery=createSprite(200,250,400,400)
  scenery.setAnimation("pine_trees_1")
  scenery.scale=1.2
  house = createSprite(370,350,10,10);
  house.setAnimation("beachhouse_03_1")
  house.scale=0.45
  
  
  
  grandmaa = createSprite(20,370,13,13);
  grandmaa.setAnimation("rpgcharacter_11_1")
  grandmaa.scale=0.15
  
  
  fox1 = createSprite(80,250,10,10);
  fox1.setAnimation("fox_1")
  fox1.scale=0.06
  fox2 = createSprite(200,250,10,10);
  fox2.setAnimation("fox_2")
  fox2.scale=0.06
  fox3 = createSprite(135,250,10,10);
  fox3.setAnimation("fox_3")
  fox3.scale=0.06
  fox4 = createSprite(270,250,10,10);
  fox4.setAnimation("fox_4")
  fox4.scale=0.06
  
  boundary1=createSprite(200,88,400,3)
 boundary2=createSprite(200,398,400,3)
 
//add the velocity to make the car move.
fox1.velocityY=12
fox2.velocityY=12
fox3.velocityY=-12
fox4.velocityY=-12

function draw() {
   background("white");
   //display lives
   textSize(18)
   stroke("red")
  text("lives: " + life,300,30)
 
//Add the condition to make the sam move left and right
if(keyDown("left")){
  grandmaa.x=grandmaa.x-3
}
if(keyDown("right")){
  grandmaa.x=grandmaa.x+3
}
//Add the condition to reduce the SCORE of sam if it touches the car.
if( grandmaa.isTouching(fox1)|| grandmaa.isTouching(fox2)|| grandmaa.isTouching(fox3)|| grandmaa.isTouching(fox4))
{playSound( "assets/category_transition/retro_game_enemy_teleport_5.mp3")
  grandmaa.x = 20; grandmaa.y = 370; life = life + 1; }
  
  if(grandmaa.isTouching(house)){
  background("black")
  grandmaa.destroy(house)
  fox1.setVelocity(0,0)
  fox2.setVelocity(0,0)
  fox3.setVelocity(0,0)
  fox4.setVelocity(0,0)
  textSize(25)
  text("thx for your help",80,20)
}

 
createEdgeSprites();
fox1.bounceOff(boundary1)
fox1.bounceOff(boundary2)
fox2.bounceOff(boundary1)
fox2.bounceOff(boundary2)
fox3.bounceOff(boundary1)
fox3.bounceOff(boundary2)
fox4.bounceOff(boundary1)
fox4.bounceOff(boundary2)


 drawSprites();
}

// -----
    try { window.draw = draw; } catch (e) {}
    switch (stage) {
      case 'preload':
        if (preload !== window.preload) { preload(); }
        break;
      case 'setup':
        if (setup !== window.setup) { setup(); }
        break;
    }
  }
  window.wrappedExportedCode = wrappedExportedCode;
  wrappedExportedCode('preload');
};

window.setup = function () {
  window.wrappedExportedCode('setup');
};
